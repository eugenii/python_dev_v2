from django.shortcuts import render, get_object_or_404
from django.utils import timezone

from blog.models import Category, Post
from blog.constants import INDEX_PAGE_POSTS_NUMBER


def get_published_posts(queryset=None):
    """Возвращает отфильтрованный и оптимизированный QuerySet постов."""
    if queryset is None:
        queryset = Post.objects.all()

    return queryset.select_related(
        'category', 'location', 'author'
    ).filter(
        is_published=True,
        category__is_published=True,
        pub_date__lte=timezone.now()
    )


def index(request):
    post_list = get_published_posts()

    context = {
        'post_list': post_list[:INDEX_PAGE_POSTS_NUMBER],
    }

    return render(request, 'blog/index.html', context)


def post_detail(request, post_id):

    queryset = get_published_posts()

    post = get_object_or_404(queryset, pk=post_id)

    context = {
        'post': post,
    }
    return render(request, 'blog/detail.html', context)


def category_posts(request, category_slug):
    category = get_object_or_404(
        Category,
        slug=category_slug,
        is_published=True
    )

    post_list = get_published_posts(
        category.posts.select_related('location', 'author')
    )

    post_list = get_published_posts(category.posts)

    context = {
        'category': category,
        'post_list': post_list,
    }
    return render(request, 'blog/category.html', context)
